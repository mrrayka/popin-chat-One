const socket = io();

// Screens
const nicknameScreen = document.getElementById('nickname-screen');
const waitingScreen = document.getElementById('waiting-screen');
const chatScreen = document.getElementById('chat-screen');
const bannedScreen = document.getElementById('banned-screen');
const reportModal = document.getElementById('report-modal');

// Elements
const nicknameInput = document.getElementById('nickname-input');
const startBtn = document.getElementById('start-btn');
const cancelWaitBtn = document.getElementById('cancel-wait-btn');
const skipBtn = document.getElementById('skip-btn');
const stopBtn = document.getElementById('stop-btn');
const reportBtn = document.getElementById('report-btn');
const reportSubmitBtn = document.getElementById('report-submit-btn');
const reportCancelBtn = document.getElementById('report-cancel-btn');
const partnerNameEl = document.getElementById('partner-name');
const messagesEl = document.getElementById('messages');
const messageInput = document.getElementById('message-input');
const sendBtn = document.getElementById('send-btn');
const typingIndicator = document.getElementById('typing-indicator');

function showScreen(screen) {
  [nicknameScreen, waitingScreen, chatScreen, bannedScreen].forEach(s => s.classList.add('hidden'));
  screen.classList.remove('hidden');
}

function addMessage(text, type) {
  const div = document.createElement('div');
  div.className = `msg ${type}`;
  div.textContent = text;
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

// ---- Nickname submit ----
startBtn.addEventListener('click', () => {
  const nickname = nicknameInput.value.trim();
  socket.emit('set-nickname', nickname);
});
nicknameInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') startBtn.click();
});

socket.on('nickname-accepted', () => {
  showScreen(waitingScreen);
  socket.emit('find-partner');
});

socket.on('banned', () => {
  showScreen(bannedScreen);
});

// ---- Pairing ----
socket.on('paired', ({ partnerNickname }) => {
  messagesEl.innerHTML = '';
  partnerNameEl.textContent = partnerNickname;
  addMessage(`You are now chatting with ${partnerNickname}`, 'system');
  showScreen(chatScreen);
  messageInput.focus();
});

socket.on('partner-left', () => {
  addMessage('Stranger has disconnected.', 'system');
});

socket.on('system-message', (text) => {
  addMessage(text, 'system');
});

// ---- Messaging ----
function sendMessage() {
  const text = messageInput.value.trim();
  if (!text) return;
  addMessage(text, 'mine');
  socket.emit('send-message', text);
  messageInput.value = '';
}
sendBtn.addEventListener('click', sendMessage);
messageInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') sendMessage();
  else socket.emit('typing');
});

socket.on('receive-message', ({ text }) => {
  addMessage(text, 'theirs');
  typingIndicator.classList.add('hidden');
});

socket.on('partner-typing', () => {
  typingIndicator.classList.remove('hidden');
  clearTimeout(window._typingTimeout);
  window._typingTimeout = setTimeout(() => typingIndicator.classList.add('hidden'), 2000);
});

// ---- Skip / Stop ----
skipBtn.addEventListener('click', () => {
  socket.emit('skip');
  showScreen(waitingScreen);
});

stopBtn.addEventListener('click', () => {
  socket.emit('stop-chat');
  showScreen(nicknameScreen);
  nicknameInput.value = '';
});

cancelWaitBtn.addEventListener('click', () => {
  socket.emit('stop-chat');
  showScreen(nicknameScreen);
});

// ---- Report ----
reportBtn.addEventListener('click', () => {
  reportModal.classList.remove('hidden');
});
reportCancelBtn.addEventListener('click', () => {
  reportModal.classList.add('hidden');
  document.getElementById('report-reason').value = '';
});
reportSubmitBtn.addEventListener('click', () => {
  const reason = document.getElementById('report-reason').value.trim();
  socket.emit('report', { reason });
  reportModal.classList.add('hidden');
  document.getElementById('report-reason').value = '';
});

// ---- Kicked ----
socket.on('kicked', ({ reason }) => {
  alert(`You were disconnected by admin: ${reason || ''}`);
  showScreen(nicknameScreen);
});
