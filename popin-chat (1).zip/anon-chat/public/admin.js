const loginScreen = document.getElementById('login-screen');
const dashboardScreen = document.getElementById('dashboard-screen');
const passwordInput = document.getElementById('password-input');
const loginBtn = document.getElementById('login-btn');
const loginError = document.getElementById('login-error');
const logoutBtn = document.getElementById('logout-btn');

let pollInterval = null;

async function checkAuth() {
  const res = await fetch('/admin/status');
  const data = await res.json();
  if (data.isAdmin) {
    showDashboard();
  } else {
    loginScreen.classList.remove('hidden');
    dashboardScreen.classList.add('hidden');
  }
}

loginBtn.addEventListener('click', async () => {
  const password = passwordInput.value;
  const res = await fetch('/admin/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password })
  });
  const data = await res.json();
  if (data.success) {
    showDashboard();
  } else {
    loginError.textContent = 'Incorrect password';
  }
});

passwordInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') loginBtn.click();
});

logoutBtn.addEventListener('click', async () => {
  await fetch('/admin/logout', { method: 'POST' });
  clearInterval(pollInterval);
  loginScreen.classList.remove('hidden');
  dashboardScreen.classList.add('hidden');
});

function showDashboard() {
  loginScreen.classList.add('hidden');
  dashboardScreen.classList.remove('hidden');
  fetchStats();
  pollInterval = setInterval(fetchStats, 3000);
}

async function fetchStats() {
  const res = await fetch('/admin/stats');
  if (res.status === 401) {
    clearInterval(pollInterval);
    loginScreen.classList.remove('hidden');
    dashboardScreen.classList.add('hidden');
    return;
  }
  const data = await res.json();
  renderStats(data);
}

function renderStats(data) {
  document.getElementById('stat-online').textContent = data.totalOnline;
  document.getElementById('stat-waiting').textContent = data.waiting;
  document.getElementById('stat-chats').textContent = data.activeChats;
  document.getElementById('stat-banned').textContent = data.bannedIPs.length;
  document.getElementById('stat-reports').textContent = data.reports.length;

  // Users table
  const usersBody = document.getElementById('users-table-body');
  usersBody.innerHTML = data.users.map(u => `
    <tr>
      <td>${escapeHtml(u.nickname)}</td>
      <td><span class="badge ${u.status}">${u.status}</span></td>
      <td>${escapeHtml(u.ip)}</td>
      <td>${new Date(u.connectedAt).toLocaleTimeString()}</td>
      <td>
        <button class="action-btn" onclick="kickUser('${u.id}')">Kick</button>
        <button class="action-btn danger" onclick="banUser('${u.id}')">Ban</button>
      </td>
    </tr>
  `).join('') || '<tr><td colspan="5" style="color:#666;">No users online</td></tr>';

  // Reports table
  const reportsBody = document.getElementById('reports-table-body');
  reportsBody.innerHTML = data.reports.slice().reverse().map(r => `
    <tr>
      <td>${escapeHtml(r.from)}</td>
      <td>${escapeHtml(r.against)}</td>
      <td>${escapeHtml(r.reason)}</td>
      <td>${new Date(r.time).toLocaleString()}</td>
      <td>${r.againstIP ? `<button class="action-btn danger" onclick="banIP('${r.againstIP}')">Ban IP</button>` : '-'}</td>
    </tr>
  `).join('') || '<tr><td colspan="5" style="color:#666;">No reports</td></tr>';

  // Banned IPs table
  const bannedBody = document.getElementById('banned-table-body');
  bannedBody.innerHTML = data.bannedIPs.map(ip => `
    <tr>
      <td>${escapeHtml(ip)}</td>
      <td><button class="action-btn" onclick="unbanIP('${ip}')">Unban</button></td>
    </tr>
  `).join('') || '<tr><td colspan="2" style="color:#666;">No banned IPs</td></tr>';
}

async function kickUser(socketId) {
  await fetch('/admin/kick', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ socketId })
  });
  fetchStats();
}

async function banUser(socketId) {
  if (!confirm('Ban this user\'s IP address?')) return;
  await fetch('/admin/ban', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ socketId })
  });
  fetchStats();
}

async function banIP(ip) {
  if (!confirm(`Ban IP ${ip}?`)) return;
  await fetch('/admin/ban', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ip })
  });
  fetchStats();
}

async function unbanIP(ip) {
  await fetch('/admin/unban', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ip })
  });
  fetchStats();
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

checkAuth();
